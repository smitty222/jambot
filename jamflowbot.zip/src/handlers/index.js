import message from './message.js'
import handleUserJoinedWithStatePatch from './userJoined.js'

export const handlers = {
  message,
  handleUserJoinedWithStatePatch
}

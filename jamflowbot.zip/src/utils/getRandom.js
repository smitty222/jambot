export const getRandomFromArray = (array) => {
  return array[Math.floor(Math.random() * array.length)]
}
